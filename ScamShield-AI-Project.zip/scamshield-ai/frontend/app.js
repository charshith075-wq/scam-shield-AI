const API = 'http://localhost:8000';
const STORAGE_KEY = 'scamshield.scans.v1';
const $ = (selector) => document.querySelector(selector);
const rules = [
  ['Urgent pressure', /\b(urgent|immediately|act now|within \d+ hours|final warning|account will be (?:closed|suspended))\b/i, 18],
  ['Requests for a one-time code or password', /\b(otp|one[- ]time (?:code|password)|verification code|password|login code)\b/i, 30],
  ['Unusual payment method', /\b(gift cards?|crypto(?:currency)?|bitcoin|wire transfer|western union|moneygram)\b/i, 25],
  ['Unexpected prize or refund', /\b(you(?:'| a)?ve won|prize winner|claim your prize|refund is waiting|claim refund)\b/i, 18],
  ['Threats or impersonation cues', /\b(police|arrest|lawsuit|tax authority|customs|fraud department|support agent)\b/i, 12],
  ['A link is included', /https?:\/\/|\bwww\./i, 12],
  ['Requests secrecy', /\b(keep this (?:secret|confidential)|don't tell anyone|do not tell anyone)\b/i, 18],
];

function level(score) { return score >= 65 ? 'high' : score >= 30 ? 'medium' : 'low'; }
function localAnalysis(text) {
  let score = 0;
  const warning_signs = [];
  for (const [label, regex, weight] of rules) if (regex.test(text)) { score += weight; warning_signs.push(label); }
  score = Math.min(score, 100);
  const risk_level = level(score);
  const recommendations = [
    'Verify the sender through a contact method you already trust.',
    'Do not share passwords, one-time codes, or payment details in response to an unexpected message.',
  ];
  if (warning_signs.includes('A link is included')) recommendations.unshift('Avoid opening the link; visit the organization’s official website directly instead.');
  if (warning_signs.includes('Unusual payment method')) recommendations.unshift('Do not pay with gift cards, cryptocurrency, or an irreversible transfer.');
  return {
    id: Date.now(), text, risk_score: score, risk_level,
    summary: warning_signs.length ? `This message has ${risk_level}-risk signals that deserve a closer look.` : 'No common warning patterns were detected, but that does not prove the message is safe.',
    warning_signs, recommendations, analysis_method: 'browser rules', created_at: new Date().toISOString(),
  };
}
function getHistory() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); } catch { return []; }
}
function saveHistory(items) { localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, 8))); }
function esc(text) { const node = document.createElement('span'); node.textContent = text; return node.innerHTML; }

function showResult(item) {
  $('#empty').hidden = true;
  const result = $('#result');
  result.hidden = false;
  $('#result-title').textContent = 'Review the signals';
  const warningHtml = item.warning_signs.length
    ? `<div class="result-block"><h3>Signals found</h3><ul>${item.warning_signs.map((x) => `<li><span class="list-mark">!</span>${esc(x)}</li>`).join('')}</ul></div>`
    : '';
  result.innerHTML = `<div class="score-row"><div class="score score-${item.risk_level}"><strong>${item.risk_score}</strong><span>/ 100</span></div><span class="badge badge-${item.risk_level}">${item.risk_level} risk</span></div><p class="summary">${esc(item.summary)}</p>${warningHtml}<div class="result-block"><h3>What to do</h3><ul>${item.recommendations.map((x) => `<li><span class="list-mark check">✓</span>${esc(x)}</li>`).join('')}</ul></div><p class="method-note">Analysis: ${esc(item.analysis_method)}</p>`;
}
function renderHistory() {
  const history = getHistory();
  $('#history-count').textContent = String(history.length).padStart(2, '0');
  $('#history-empty').hidden = history.length > 0;
  $('#history-list').innerHTML = history.map((item) => `<li><button type="button" data-id="${item.id}"><span class="history-dot ${item.risk_level}"></span><span class="history-copy"><strong>${esc(item.text.slice(0, 120))}</strong><small>${new Date(item.created_at).toLocaleString()}</small></span><span class="history-score">${item.risk_score}</span></button></li>`).join('');
}
function setError(message = '') { const box = $('#error'); box.textContent = message; box.hidden = !message; }

$('#message').addEventListener('input', (event) => { $('#counter').textContent = `${event.target.value.length.toLocaleString()} / 10,000`; });
$('#scan-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const text = $('#message').value.trim();
  if (!text) return;
  const button = $('#submit');
  button.disabled = true;
  button.innerHTML = 'Checking…';
  setError();
  try {
    let result;
    try {
      const response = await fetch(`${API}/api/scan`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }), signal: AbortSignal.timeout(2500) });
      if (!response.ok) throw new Error((await response.json()).detail || 'API request failed');
      result = await response.json();
      $('#mode').textContent = 'FastAPI connected';
    } catch {
      result = localAnalysis(text);
      $('#mode').textContent = 'Local preview · rules only';
    }
    showResult(result);
    saveHistory([result, ...getHistory().filter((x) => x.id !== result.id)]);
    renderHistory();
  } catch (error) {
    setError(error.message || 'Could not analyze this message.');
  } finally {
    button.disabled = false;
    button.innerHTML = 'Check message <span aria-hidden="true">↗</span>';
  }
});
$('#history-list').addEventListener('click', async (event) => {
  const button = event.target.closest('button[data-id]');
  if (!button) return;
  const item = getHistory().find((x) => String(x.id) === button.dataset.id);
  if (item) showResult(item);
});
renderHistory();

fetch(`${API}/health`, { signal: AbortSignal.timeout(1200) })
  .then((response) => { if (response.ok) $('#mode').textContent = 'FastAPI connected'; })
  .catch(() => { $('#mode').textContent = 'Local preview · rules only'; });
