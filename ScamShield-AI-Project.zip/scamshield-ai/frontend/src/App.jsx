import { useEffect, useState } from 'react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';

function RiskBadge({ level }) {
  return <span className={`badge badge-${level}`}>{level} risk</span>;
}

function App() {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function loadHistory() {
    try {
      const response = await fetch(`${API}/api/scans?limit=5`);
      if (!response.ok) throw new Error('API unavailable');
      setHistory(await response.json());
    } catch {
      setError('Start the FastAPI server to analyze messages and load scan history.');
    }
  }

  useEffect(() => {
    loadHistory();
  }, []);

  async function handleSubmit(event) {
    event.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    setError('');
    setResult(null);
    try {
      const response = await fetch(`${API}/api/scan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Could not analyze this message.');
      setResult(body);
      await loadHistory();
    } catch (err) {
      setError(err.message || 'Could not connect to the API.');
    } finally {
      setBusy(false);
    }
  }

  async function openHistory(id) {
    setError('');
    try {
      const response = await fetch(`${API}/api/scans/${id}`);
      if (!response.ok) throw new Error('Could not open that scan.');
      setResult(await response.json());
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="ScamShield AI home">
          <span className="brand-mark">S</span>
          <span>ScamShield<span className="brand-ai"> AI</span></span>
        </a>
        <span className="top-note"><span className="status-dot" /> Rules run locally by default</span>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">A clearer second opinion</p>
          <h1>Pause before<br /><em>you pay.</em></h1>
          <p className="hero-text">Paste a suspicious message. ScamShield checks for common warning signs and explains what to look at next.</p>
          <div className="trust-line"><span>01</span> Check the signals <i /> <span>02</span> Verify independently</div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="orbit orbit-one" /><div className="orbit orbit-two" />
          <div className="shield"><span>✓</span></div>
          <div className="float-card card-a"><span className="mini-dot amber" /> Suspicious link</div>
          <div className="float-card card-b"><span className="mini-dot green" /> Message checked</div>
          <span className="spark spark-a">✳</span><span className="spark spark-b">✳</span>
        </div>
      </section>

      <section className="workspace">
        <div className="panel scan-panel">
          <div className="section-heading">
            <div><p className="eyebrow">Message check</p><h2>What did you receive?</h2></div>
            <span className="step-number">01 / 02</span>
          </div>
          <form onSubmit={handleSubmit}>
            <label className="sr-only" htmlFor="message">Suspicious message</label>
            <textarea id="message" value={text} onChange={(event) => setText(event.target.value)} maxLength={10000} placeholder={'Paste the message here…\n\nExample: Your account will be suspended. Verify now at http://example.com'} />
            <div className="form-footer">
              <span>{text.length.toLocaleString()} / 10,000</span>
              <button className="primary-button" type="submit" disabled={busy || !text.trim()}>
                {busy ? 'Checking…' : 'Check message'} <span aria-hidden="true">↗</span>
              </button>
            </div>
          </form>
          <p className="privacy-note"><span>⌑</span> Don’t paste secrets. Message text is sent to an LLM provider only when one is configured.</p>
          {error && <div className="error-box" role="alert">{error}</div>}
        </div>

        <aside className="side-panel">
          <div className="panel result-panel">
            <div className="section-heading compact">
              <div><p className="eyebrow">Your result</p><h2>{result ? 'Review the signals' : 'Ready when you are'}</h2></div>
              <span className="result-icon">⌁</span>
            </div>
            {result ? (
              <div className="result-content">
                <div className="score-row"><div className={`score score-${result.risk_level}`}><strong>{result.risk_score}</strong><span>/ 100</span></div><RiskBadge level={result.risk_level} /></div>
                <p className="summary">{result.summary}</p>
                {result.warning_signs.length > 0 && <div className="result-block"><h3>Signals found</h3><ul>{result.warning_signs.map((item, index) => <li key={`${item}-${index}`}><span className="list-mark">!</span>{item}</li>)}</ul></div>}
                <div className="result-block"><h3>What to do</h3><ul>{result.recommendations.map((item, index) => <li key={`${item}-${index}`}><span className="list-mark check">✓</span>{item}</li>)}</ul></div>
                <p className="method-note">Analysis: {result.analysis_method === 'rules+llm' ? 'rules + LLM' : result.analysis_method.replace('_', ' ')}</p>
              </div>
            ) : <p className="empty-state">Your risk score, warning signs, and next steps will appear here.</p>}
          </div>
          <div className="history panel">
            <div className="history-heading"><h2>Recent checks</h2><span>{history.length.toString().padStart(2, '0')}</span></div>
            {history.length ? <ul className="history-list">{history.map((item) => (
              <li key={item.id}><button type="button" onClick={() => openHistory(item.id)}><span className={`history-dot ${item.risk_level}`} /><span className="history-copy"><strong>{item.text_preview || 'Message'}</strong><small>{new Date(item.created_at).toLocaleString()}</small></span><span className="history-score">{item.risk_score}</span></button></li>
            ))}</ul> : <p className="history-empty">Scans you run on this device will show up here.</p>}
          </div>
        </aside>
      </section>

      <footer className="footer"><span>ScamShield AI</span><span>Signals are a starting point, not a verdict.</span><a href="http://localhost:8000/docs" target="_blank" rel="noreferrer">API docs ↗</a></footer>
    </main>
  );
}

export default App;
