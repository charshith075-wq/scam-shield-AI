# ScamShield AI

ScamShield AI is a small hackathon MVP that helps people review suspicious messages. It combines transparent, local rule checks with optional LLM analysis and keeps a scan history in SQLite.

## Features

- Analyze pasted messages and show a 0–100 risk score.
- Explain warning signs and suggest practical next steps.
- Save recent scans to a local SQLite database.
- Use an OpenAI-compatible chat completions endpoint when configured; otherwise use the built-in rule analyzer.
- Keep the frontend usable without sending message text to a model provider unless LLM settings are configured.

This is a decision-support demo, not a guarantee that a message is safe or fraudulent. Avoid entering passwords, one-time codes, or other secrets.

## Run locally

### Backend

Requires Python 3.10 or newer.

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --reload
```

The API runs at `http://localhost:8000`; interactive API docs are at `http://localhost:8000/docs`.

### Frontend

Requires Node.js 20 or newer. This preview uses Node's built-in HTTP server and has no npm dependencies, so it avoids the native Rollup module blocked by some Windows security policies.

```powershell
cd frontend
node serve.mjs
```

Open `http://localhost:5173`. The page uses local browser rules and browser storage when the FastAPI backend is offline. When the backend is running, it sends scans to FastAPI, which stores them in SQLite and can add optional LLM analysis. You can also open `frontend/index.html` directly for a local-only preview, but the API connection requires the local server.

## Optional LLM analysis

Edit `backend/.env` and set `OPENAI_API_KEY` and `OPENAI_MODEL`. For an OpenAI-compatible service, set `OPENAI_BASE_URL` to its `/v1` API root. If no key is set, the backend uses its rule analyzer only. When enabled, the submitted message is sent to the configured model provider for analysis; SQLite history stays on the local machine.

## API

- `GET /health` — service status
- `POST /api/scan` — analyze and save a message
- `GET /api/scans?limit=10` — list recent scan summaries
- `GET /api/scans/{id}` — retrieve a saved scan

## Current MVP scope

This first version analyzes text pasted by the user. Image OCR, email integrations, authentication, deployment, and PayPal transaction access are not included. Do not claim those features in a hackathon submission until they are implemented and verified.
