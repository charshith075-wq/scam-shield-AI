from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.analyzer import analyze
from app.config import CORS_ORIGINS
from app.database import Base, engine, get_db
from app.models import Scan
from app.schemas import ScanCreate, ScanListItem, ScanResult


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title="ScamShield AI API",
    description="Analyze suspicious messages with transparent rules and optional LLM support.",
    version="0.1.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/api/scan", response_model=ScanResult)
async def create_scan(payload: ScanCreate, db: Session = Depends(get_db)) -> Scan:
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="Message text cannot be blank.")
    result = await analyze(text)
    scan = Scan(
        input_text=text,
        risk_score=result.risk_score,
        risk_level=result.risk_level,
        summary=result.summary,
        warning_signs=result.warning_signs,
        recommendations=result.recommendations,
        analysis_method=result.analysis_method,
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)
    return ScanResult(
        id=scan.id,
        text=scan.input_text,
        risk_score=scan.risk_score,
        risk_level=scan.risk_level,
        summary=scan.summary,
        warning_signs=scan.warning_signs,
        recommendations=scan.recommendations,
        analysis_method=scan.analysis_method,
        created_at=scan.created_at,
    )


@app.get("/api/scans", response_model=list[ScanListItem])
def list_scans(
    limit: int = Query(default=10, ge=1, le=50), db: Session = Depends(get_db)
) -> list[ScanListItem]:
    scans = db.scalars(select(Scan).order_by(Scan.created_at.desc()).limit(limit)).all()
    return [
        ScanListItem(
            id=item.id,
            text_preview=item.input_text[:120],
            risk_score=item.risk_score,
            risk_level=item.risk_level,
            summary=item.summary,
            analysis_method=item.analysis_method,
            created_at=item.created_at,
        )
        for item in scans
    ]


@app.get("/api/scans/{scan_id}", response_model=ScanResult)
def get_scan(scan_id: int, db: Session = Depends(get_db)) -> ScanResult:
    scan = db.get(Scan, scan_id)
    if scan is None:
        raise HTTPException(status_code=404, detail="Scan not found.")
    return ScanResult(
        id=scan.id,
        text=scan.input_text,
        risk_score=scan.risk_score,
        risk_level=scan.risk_level,
        summary=scan.summary,
        warning_signs=scan.warning_signs,
        recommendations=scan.recommendations,
        analysis_method=scan.analysis_method,
        created_at=scan.created_at,
    )
