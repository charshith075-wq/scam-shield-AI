"""ScamShield AI API package."""
