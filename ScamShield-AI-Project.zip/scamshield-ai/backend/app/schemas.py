from datetime import datetime

from pydantic import BaseModel, Field


class ScanCreate(BaseModel):
    text: str = Field(min_length=1, max_length=10000)


class ScanResult(BaseModel):
    id: int
    text: str
    risk_score: int
    risk_level: str
    summary: str
    warning_signs: list[str]
    recommendations: list[str]
    analysis_method: str
    created_at: datetime


class ScanListItem(BaseModel):
    id: int
    text_preview: str
    risk_score: int
    risk_level: str
    summary: str
    analysis_method: str
    created_at: datetime
