# 🛡️ ScamShield AI

> **Real-time Scam & Fraud Detection Platform with Mobile App, OCR Screenshot Scanner, and AI Verification.**

ScamShield AI helps users analyze suspicious messages, phishing emails, SMS alerts, and payment scams before they fall victim. It combines rule-based fraud heuristics with OCR text extraction and optional Large Language Model (LLM) verification.

---

## 📱 Features

- **Mobile App (React Native / Expo)**:
  - 📷 **OCR Screenshot Scanner**: Upload or snap a screenshot of a suspicious chat, email, or text to extract the message text automatically using on-device OCR (`tesseract.js`).
  - 📋 **One-Tap Clipboard Paste**: Quickly paste messages copied from SMS, WhatsApp, Telegram, or email.
  - 🚦 **0–100 Risk Score**: Visual High / Medium / Low danger indicators.
  - ⚠️ **Signal Identification**: Detects urgent pressure, OTP/password requests, cryptocurrency/gift card payment traps, and phishing domains.
  - 🛡️ **Actionable Protection Advice**: Clear step-by-step guidance on what to do next.
  - 📜 **Scan History**: Stores previous checks locally on device.
  - 🔌 **Offline First**: Runs client-side heuristic rules locally even without internet connection, and synchronizes with the backend when online.

- **FastAPI Backend**:
  - High-performance asynchronous REST API.
  - SQLite persistence (`scamshield.db`) for tracking scan logs and threat telemetry.
  - Optional OpenAI / LLM chat completion integration with transparent rule floors.

- **Web Dashboard**:
  - Lightweight, responsive desktop dashboard with zero-build requirements.

---

## 🏗️ Project Architecture

```text
PERLIONZED/
├── scamshield-mobile/          # React Native & Expo Mobile Application
│   ├── App.js                  # Main UI, OCR Screenshot reader & Scanner logic
│   ├── package.json            # Expo SDK 58, tesseract.js, expo-image-picker
│   └── app.json                # Expo mobile configuration
│
├── scamshield-ai/
│   ├── backend/                # FastAPI Python Backend
│   │   ├── app/
│   │   │   ├── main.py         # REST Endpoints (/api/scan, /api/scans, /health)
│   │   │   ├── analyzer.py     # Heuristic Rule Engine + LLM fallback
│   │   │   ├── models.py       # SQLAlchemy ORM Models
│   │   │   ├── database.py     # SQLite Database setup
│   │   │   └── config.py       # Environment configuration
│   │   └── requirements.txt    # FastAPI, Uvicorn, SQLAlchemy, Pydantic
│   │
│   └── frontend/               # Responsive Web Dashboard
│       ├── index.html          # Web UI layout
│       ├── app.js              # Web client logic & local analysis fallback
│       ├── styles.css          # Styling
│       └── serve.mjs           # Node.js preview server
│
├── .gitignore                  # Git exclusions (node_modules, venvs, DBs)
└── README.md                   # Project documentation
```

---

## 🚀 Quick Start Guide

### 1. Mobile App (React Native / Expo)

```bash
cd scamshield-mobile
npm install
npx expo start
```

- Press `w` to open in browser (Web preview: `http://localhost:8081`).
- Press `a` for Android emulator or `i` for iOS simulator.
- Or scan the QR code with the **Expo Go** app on your physical iPhone / Android device.

---

### 2. Backend API (FastAPI)

Requires Python 3.10+:

```powershell
cd scamshield-ai/backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python -m uvicorn app.main:app --reload --port 8000
```

- API runs on `http://127.0.0.1:8000`
- Interactive Swagger docs available at `http://127.0.0.1:8000/docs`

---

### 3. Web Dashboard

```bash
cd scamshield-ai/frontend
node serve.mjs
```

- Web dashboard runs on `http://localhost:5173`

---

## 🔒 Privacy & Safety

- ScamShield AI performs heuristic evaluations locally on your device by default.
- Messages are only sent to third-party LLM providers if explicitly configured in `backend/.env`.
- Do not paste personal passwords, private keys, or confidential banking credentials.

---

## 📄 License

MIT License. Developed for hackathons and security awareness.
