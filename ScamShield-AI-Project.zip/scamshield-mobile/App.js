import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  ActivityIndicator,
  Image,
  Alert,
  Platform,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import * as Clipboard from 'expo-clipboard';
import { createWorker } from 'tesseract.js';

// Default to local backend; works across device emulators and web
const BACKEND_API = 'http://localhost:8000';

const LOCAL_RULES = [
  { label: 'Urgent pressure & threat', pattern: /\b(urgent|immediately|act now|within \d+ hours|final warning|account will be (?:closed|suspended|locked))\b/i, weight: 20 },
  { label: 'Requests for OTP or password', pattern: /\b(otp|one[- ]time (?:code|password)|verification code|password|pin|login code)\b/i, weight: 30 },
  { label: 'Unusual payment method', pattern: /\b(gift cards?|crypto(?:currency)?|bitcoin|wire transfer|western union|moneygram|cashapp|venmo)\b/i, weight: 25 },
  { label: 'Unexpected prize or refund', pattern: /\b(you(?:'| a)?ve won|prize winner|claim your prize|refund is waiting|claim refund|lottery)\b/i, weight: 20 },
  { label: 'Impersonation cues', pattern: /\b(police|arrest|lawsuit|tax authority|customs|fraud department|support agent|bank fraud)\b/i, weight: 15 },
  { label: 'Suspicious link included', pattern: /https?:\/\/|\bwww\.|\.xyz|\.top|\.ru|\.click/i, weight: 15 },
  { label: 'Demand for secrecy', pattern: /\b(keep this (?:secret|confidential)|don't tell anyone|do not share this)\b/i, weight: 20 },
];

function analyzeLocally(text) {
  let score = 0;
  const signs = [];
  for (const rule of LOCAL_RULES) {
    if (rule.pattern.test(text)) {
      signs.push(rule.label);
      score += rule.weight;
    }
  }
  score = Math.min(score, 100);
  const level = score >= 65 ? 'high' : score >= 30 ? 'medium' : 'low';
  
  const recommendations = [
    'Verify the sender directly through official contact info you know and trust.',
    'Never share passwords, 2FA/OTP codes, or banking details over unverified messages.',
  ];
  if (signs.includes('Suspicious link included')) {
    recommendations.unshift('Avoid tapping the link. Go to the official domain directly in your browser.');
  }
  if (signs.includes('Unusual payment method')) {
    recommendations.unshift('Never pay with gift cards, cryptocurrency, or peer-to-peer apps.');
  }

  return {
    risk_score: score,
    risk_level: level,
    summary: signs.length > 0
      ? `This message displays ${level}-risk signals that warrant extreme caution.`
      : 'No standard scam patterns detected, but always verify before sending funds or data.',
    warning_signs: signs,
    recommendations,
    analysis_method: 'Client-side Engine (Offline Ready)',
  };
}

export default function App() {
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [ocrStatus, setOcrStatus] = useState('');
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [activeTab, setActiveTab] = useState('scan'); // 'scan' | 'history'

  const pickImage = async (useCamera = false) => {
    try {
      const permission = useCamera
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permission.granted) {
        Alert.alert('Permission Denied', 'Please enable camera/gallery access to scan screenshots.');
        return;
      }

      const pickerResult = useCamera
        ? await ImagePicker.launchCameraAsync({ quality: 0.8, allowsEditing: true })
        : await ImagePicker.launchImageLibraryAsync({ quality: 0.8, allowsEditing: true });

      if (!pickerResult.canceled && pickerResult.assets?.[0]?.uri) {
        const imageUri = pickerResult.assets[0].uri;
        setSelectedImage(imageUri);
        processOcr(imageUri);
      }
    } catch (err) {
      Alert.alert('Error', 'Unable to pick image: ' + err.message);
    }
  };

  const processOcr = async (imageUri) => {
    setLoading(true);
    setOcrStatus('Extracting text from screenshot with OCR...');
    try {
      const worker = await createWorker('eng');
      const ret = await worker.recognize(imageUri);
      await worker.terminate();

      const extracted = ret.data.text.trim();
      if (extracted) {
        setInputText(extracted);
        setOcrStatus('Text extracted successfully!');
      } else {
        setOcrStatus('No clear text found in image. Please type or paste directly.');
      }
    } catch (err) {
      setOcrStatus('OCR extraction failed. You can paste the text manually.');
    } finally {
      setLoading(false);
    }
  };

  const pasteFromClipboard = async () => {
    const text = await Clipboard.getStringAsync();
    if (text) {
      setInputText(text);
    } else {
      Alert.alert('Clipboard Empty', 'No text found on your clipboard.');
    }
  };

  const handleScan = async () => {
    if (!inputText.trim()) {
      Alert.alert('Input Needed', 'Please paste a suspicious message or upload a screenshot first.');
      return;
    }

    setLoading(true);
    setResult(null);

    // Try backend API first, automatically fall back to local rule analysis if offline
    try {
      const response = await fetch(`${BACKEND_API}/api/scan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText }),
      });

      if (response.ok) {
        const data = await response.json();
        setResult(data);
        setHistory(prev => [data, ...prev]);
        setLoading(false);
        return;
      }
    } catch (_) {
      // Backend unreachable or offline: fallback smoothly
    }

    // Local engine fallback
    const localRes = analyzeLocally(inputText);
    setResult(localRes);
    setHistory(prev => [localRes, ...prev]);
    setLoading(false);
  };

  const getScoreColor = (level) => {
    if (level === 'high') return '#ef4444';
    if (level === 'medium') return '#f59e0b';
    return '#10b981';
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <View style={styles.brandBadge}>
            <Text style={styles.brandBadgeText}>🛡️</Text>
          </View>
          <View>
            <Text style={styles.brandTitle}>ScamShield Mobile</Text>
            <Text style={styles.brandSubtitle}>AI & OCR Fraud Detection</Text>
          </View>
        </View>
        <View style={styles.navRow}>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'scan' && styles.tabButtonActive]}
            onPress={() => setActiveTab('scan')}
          >
            <Text style={[styles.tabButtonText, activeTab === 'scan' && styles.tabButtonTextActive]}>
              Scanner
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'history' && styles.tabButtonActive]}
            onPress={() => setActiveTab('history')}
          >
            <Text style={[styles.tabButtonText, activeTab === 'history' && styles.tabButtonTextActive]}>
              History ({history.length})
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {activeTab === 'scan' ? (
          <>
            <View style={styles.card}>
              <Text style={styles.cardHeader}>Scan Suspicious Message or Screenshot</Text>
              <Text style={styles.cardDesc}>
                Take a photo, upload a chat screenshot, or paste text below to evaluate scam signals.
              </Text>

              {/* Action Buttons for Screenshot / OCR */}
              <View style={styles.actionRow}>
                <TouchableOpacity style={styles.actionBtn} onPress={() => pickImage(false)}>
                  <Text style={styles.actionBtnIcon}>🖼️</Text>
                  <Text style={styles.actionBtnText}>Screenshot</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.actionBtn} onPress={() => pickImage(true)}>
                  <Text style={styles.actionBtnIcon}>📷</Text>
                  <Text style={styles.actionBtnText}>Camera</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.actionBtn} onPress={pasteFromClipboard}>
                  <Text style={styles.actionBtnIcon}>📋</Text>
                  <Text style={styles.actionBtnText}>Paste</Text>
                </TouchableOpacity>
              </View>

              {/* Screenshot Preview */}
              {selectedImage && (
                <View style={styles.imagePreviewContainer}>
                  <Image source={{ uri: selectedImage }} style={styles.imagePreview} />
                  {ocrStatus ? <Text style={styles.ocrStatusText}>{ocrStatus}</Text> : null}
                </View>
              )}

              {/* Message Input Box */}
              <TextInput
                style={styles.textInput}
                multiline
                numberOfLines={5}
                placeholder="Paste or type suspicious message here (e.g. 'URGENT: Your account will be closed. Verify password immediately')..."
                placeholderTextColor="#64748b"
                value={inputText}
                onChangeText={setInputText}
              />

              <TouchableOpacity
                style={[styles.scanButton, loading && styles.scanButtonDisabled]}
                onPress={handleScan}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#0f172a" />
                ) : (
                  <Text style={styles.scanButtonText}>Analyze Message Risk ⚡</Text>
                )}
              </TouchableOpacity>
            </View>

            {/* Analysis Result Card */}
            {result && (
              <View style={[styles.card, styles.resultCard]}>
                <View style={styles.resultHeader}>
                  <View>
                    <Text style={styles.resultTitle}>Risk Assessment</Text>
                    <Text style={styles.resultMethod}>{result.analysis_method}</Text>
                  </View>
                  <View style={[styles.scorePill, { backgroundColor: getScoreColor(result.risk_level) }]}>
                    <Text style={styles.scorePillText}>{result.risk_score} / 100</Text>
                  </View>
                </View>

                <View style={[styles.riskLevelBadge, { borderColor: getScoreColor(result.risk_level) }]}>
                  <Text style={[styles.riskLevelText, { color: getScoreColor(result.risk_level) }]}>
                    {result.risk_level?.toUpperCase()} RISK DETECTED
                  </Text>
                </View>

                <Text style={styles.resultSummary}>{result.summary}</Text>

                {result.warning_signs?.length > 0 && (
                  <View style={styles.sectionBlock}>
                    <Text style={styles.sectionTitle}>⚠️ Warning Signals Detected</Text>
                    {result.warning_signs.map((sign, index) => (
                      <View key={index} style={styles.bulletRow}>
                        <Text style={styles.bulletSign}>•</Text>
                        <Text style={styles.bulletText}>{sign}</Text>
                      </View>
                    ))}
                  </View>
                )}

                {result.recommendations?.length > 0 && (
                  <View style={styles.sectionBlock}>
                    <Text style={styles.sectionTitle}>🛡️ Protective Actions</Text>
                    {result.recommendations.map((rec, index) => (
                      <View key={index} style={styles.bulletRow}>
                        <Text style={[styles.bulletSign, { color: '#10b981' }]}>✓</Text>
                        <Text style={styles.bulletText}>{rec}</Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            )}
          </>
        ) : (
          <View style={styles.card}>
            <Text style={styles.cardHeader}>Recent Scans</Text>
            {history.length === 0 ? (
              <Text style={styles.emptyText}>No previous scans on this device yet.</Text>
            ) : (
              history.map((item, index) => (
                <View key={index} style={styles.historyItem}>
                  <View style={styles.historyTop}>
                    <View style={[styles.historyDot, { backgroundColor: getScoreColor(item.risk_level) }]} />
                    <Text style={styles.historyScore}>Risk: {item.risk_score}/100 ({item.risk_level})</Text>
                  </View>
                  <Text style={styles.historySummary}>{item.summary}</Text>
                </View>
              ))
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0a0f1d',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'android' ? 40 : 15,
    paddingBottom: 15,
    backgroundColor: '#0f172a',
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  brandBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#1e293b',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  brandBadgeText: {
    fontSize: 22,
  },
  brandTitle: {
    color: '#f8fafc',
    fontSize: 20,
    fontWeight: '700',
  },
  brandSubtitle: {
    color: '#94a3b8',
    fontSize: 12,
  },
  navRow: {
    flexDirection: 'row',
    gap: 10,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: '#1e293b',
    alignItems: 'center',
  },
  tabButtonActive: {
    backgroundColor: '#38bdf8',
  },
  tabButtonText: {
    color: '#94a3b8',
    fontWeight: '600',
    fontSize: 14,
  },
  tabButtonTextActive: {
    color: '#0f172a',
    fontWeight: '700',
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  card: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: '#1e293b',
  },
  cardHeader: {
    color: '#f8fafc',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  cardDesc: {
    color: '#94a3b8',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 16,
  },
  actionRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  actionBtn: {
    flex: 1,
    backgroundColor: '#1e293b',
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  actionBtnIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  actionBtnText: {
    color: '#e2e8f0',
    fontSize: 12,
    fontWeight: '600',
  },
  imagePreviewContainer: {
    alignItems: 'center',
    marginBottom: 14,
  },
  imagePreview: {
    width: '100%',
    height: 160,
    borderRadius: 10,
    resizeMode: 'cover',
  },
  ocrStatusText: {
    color: '#38bdf8',
    fontSize: 12,
    marginTop: 6,
  },
  textInput: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    color: '#f8fafc',
    padding: 14,
    fontSize: 14,
    textAlignVertical: 'top',
    minHeight: 110,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 16,
  },
  scanButton: {
    backgroundColor: '#38bdf8',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  scanButtonDisabled: {
    opacity: 0.6,
  },
  scanButtonText: {
    color: '#0f172a',
    fontSize: 15,
    fontWeight: '700',
  },
  resultCard: {
    borderColor: '#334155',
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  resultTitle: {
    color: '#f8fafc',
    fontSize: 18,
    fontWeight: '700',
  },
  resultMethod: {
    color: '#64748b',
    fontSize: 11,
    marginTop: 2,
  },
  scorePill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  scorePillText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 14,
  },
  riskLevelBadge: {
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  riskLevelText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  resultSummary: {
    color: '#cbd5e1',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16,
  },
  sectionBlock: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#1e293b',
  },
  sectionTitle: {
    color: '#e2e8f0',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 8,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 6,
    gap: 8,
  },
  bulletSign: {
    color: '#f59e0b',
    fontSize: 14,
    fontWeight: '800',
  },
  bulletText: {
    color: '#94a3b8',
    fontSize: 13,
    flex: 1,
    lineHeight: 18,
  },
  emptyText: {
    color: '#64748b',
    fontSize: 14,
    textAlign: 'center',
    paddingVertical: 20,
  },
  historyItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  historyTop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    gap: 8,
  },
  historyDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  historyScore: {
    color: '#e2e8f0',
    fontWeight: '700',
    fontSize: 13,
  },
  historySummary: {
    color: '#94a3b8',
    fontSize: 12,
  },
});
